package qjt.wm.freq;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.io.StringReader;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map.Entry;
import java.util.Set;
import java.util.StringTokenizer;
import java.util.Vector;

import org.apache.lucene.analysis.Analyzer;
import org.apache.lucene.analysis.TokenStream;
import org.apache.lucene.analysis.tokenattributes.CharTermAttribute;
import org.apache.lucene.analysis.tokenattributes.OffsetAttribute;
import org.apache.lucene.analysis.tokenattributes.TypeAttribute;
import org.wltea.analyzer.lucene.IKAnalyzer;

/**
 * ͳ�������ı��Ĵ�Ƶ
 * 2016.03 -- J. Qiu
 * */
public class TermFrequency {
//	String fname="www2016.txt";
	private String fname;

	private int k=20;				// ���top k��terms
	private int n=4;				// n-gram
	private boolean useNG=false;	//true:ʹ��N-gram; false: ʹ�÷ִ�
	
	public static void main(String args[]){
		TermFrequency ex = new TermFrequency();
		String fname="d:\\qjt\\beike\\��Ϣ����\\2016����\\1\\rdbg2015.txt";
		try {
			ex.run(fname, 20);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	public String run(String fname, int k) throws Exception{
		this.fname=fname;
		this.k=k;
		BufferedReader fis=new BufferedReader(new FileReader(fname));
		HashMap<String, Integer> hmap = new HashMap<String, Integer>();
		String line;
		StringBuilder sb = new StringBuilder();
		while(true){
			line=fis.readLine();
			if(line==null) break;
			if(line.isEmpty()) continue;
			line=line.trim();
			sb.append(line);
		}
//		System.out.println(sb);
		String delim="������;��";
		StringTokenizer st = new StringTokenizer(sb.toString(), delim);
		String sentence;
		
		while(st.hasMoreTokens()){
			sentence=st.nextToken();
			if(useNG){
				put(sentence, hmap);
			}else{
				put2(sentence, hmap);
			}
		}
		
		Set<Entry<String, Integer>> set = hmap.entrySet();
		Iterator<Entry<String, Integer>>  it = set.iterator();
		Entry<String, Integer> entry;
		MyList mylist = new MyList(k);
		while(it.hasNext()){
			entry = it.next();
			mylist.insert(entry.getKey(), entry.getValue());
		}
		String str,res="";
		k=1;
		
		while(true){
			str=mylist.next();
			if(str==null) break;
			res+=(k++)+" "+str+";\n";
		}
		return res;
	}
	/**
	 * n-gram
	 * */
	private void put(String sentence, HashMap<String, Integer> hmap){
		int begin=0;
		String sub;
		Integer count;
		while(true){
			if(sentence.length()<=n){
				sub=sentence;
			}else{
				sub = sentence.substring(begin, begin+n);
			}
			count = hmap.get(sub);
			if(count==null){
				hmap.put(sub, 1);
			}else{
				hmap.put(sub, count+1);
			}
			begin++;
			if(begin+n>=sentence.length()) break;
		}
	}
	/**
	 * ʹ�����ķִ�
	 * */
	private void put2(String sentence, HashMap<String, Integer> hmap){
		Analyzer analyzer = new IKAnalyzer(true);
		
	    TokenStream ts = null;
	    String token;
	    Integer count;
	    
		try {
			ts = analyzer.tokenStream("myfield", new StringReader(sentence));
		    CharTermAttribute term  = ts.addAttribute(CharTermAttribute.class);
		    
			ts.reset(); 
			while (ts.incrementToken()) {
				token=term.toString();
				count = hmap.get(token);
				if(count==null){
					hmap.put(token, 1);
				}else{
					hmap.put(token, count+1);
				}
			}
			ts.end(); 
		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			if(ts != null){
				try {
					ts.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
	    }
		analyzer.close();
	}
}

