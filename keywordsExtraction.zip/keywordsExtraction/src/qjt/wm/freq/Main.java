package qjt.wm.freq;

public class Main {
	public String run(String fname, int k){
		TermFrequency tf=new TermFrequency();
		String res="NULL";
		try {
			res=tf.run(fname, k);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return res;
	}
	public static void main(String[] args){
//		String fname="d:\\qjt\\beike\\��Ϣ����\\2016����\\1\\rdbg2015.txt";
//		String fname="www2016.txt";
		String fname="rdbg2018.txt";
		int k=200;
		Main m=new Main();
		String str=m.run(fname, k);
		System.out.println(str);
	}
}


