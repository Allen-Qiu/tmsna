package qjt.wm.freq;

import java.util.Vector;

/**
 * ����һ������Ϊlen�ĸ������飬��ɲ���������
 * */
public class MyList{
	Vector<Ele> vec;
	private int len;
	private int index;
	
	public MyList(int len){
		this.len=len;
		vec = new Vector<Ele>();
		index=0;
	}
	public void print(){
		Ele ele;
		for(int i=0;i<vec.size();i++){
			ele = vec.get(i);
			System.out.println(ele.str+":"+ele.val);
		}
	}
	public void insert(String str, double val){
		if(vec.size()==0) {
			vec.add(new Ele(str,val));
			return;
		}
		int k=0;
		Ele ele;
		
		while(true){
			if(k==len) break;
			if(k==vec.size()){
				vec.add(new Ele(str,val));
				break;
			}
			ele=vec.get(k);
			if(ele.val<=val) {
				vec.add(k, new Ele(str,val));
				break;
			}
			k++;
		}
		if(vec.size()>len){
			vec.remove(len);
		}
	}
	
	public String next(){
		if(index==len) {
			index=0;
			return null;
		}
		return vec.get(index++).str;
	}
	public int size(){
		return len;
	}
	
	class Ele{
		String str;
		double val;
		Ele(String str, double val){
			this.str=str;
			this.val=val;
		}
	}
}






