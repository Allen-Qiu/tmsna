package qjt.wm.freq;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.RandomAccessFile;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Set;
import java.util.StringTokenizer;
import java.util.Map.Entry;

import org.apache.pdfbox.cos.COSDocument;
import org.apache.pdfbox.pdfparser.PDFParser;
import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.util.PDFTextStripper;

import edu.stanford.nlp.process.Morphology;

/**
 * ͳ��һƪpdf�ĵ��Ĵ�Ƶ
 * */
public class Example2 {
	String fname="published.pdf";
	int k=20; 					// top k terms
	boolean useStopList=true; 	//�Ƿ���ͣ�ô�
	boolean useStem=false;		// stemming��+
	
	
	public static void main(String[] args){
		Example2 exa=new Example2();
		try {
			exa.run();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	private void run() throws Exception{
		HashSet<String> stoplist = null;
		Morphology m=null;
		
		if(useStopList){
			stoplist = buildStopList();
		}
		if(useStem){
			m=new Morphology();
		}
		
		HashMap<String, Integer> hmap = new HashMap<String, Integer>();
		String str = extract();
		String delim=" ,.?:()";
		StringTokenizer st = new StringTokenizer(str, delim);
		String token;
		Integer count;
		
		while(st.hasMoreTokens()){
			token=st.nextToken();
			if(token.isEmpty())continue;
			if(m!=null){
				token = m.stem(token);
				if(token.isEmpty()) continue;
			}
			if(stoplist!=null && stoplist.contains(token)) continue;
			count = hmap.get(token);
			if(count==null){
				hmap.put(token, 1);
			}else{
				hmap.put(token, count+1);
			}
		}
		
		Set<Entry<String, Integer>> set = hmap.entrySet();
		Iterator<Entry<String, Integer>>  it = set.iterator();
		Entry<String, Integer> entry;
		MyList mylist = new MyList(k);
		while(it.hasNext()){
			entry = it.next();
			mylist.insert(entry.getKey(), entry.getValue());
		}
		mylist.print();
		
	}
	private String extract(){
		PDFTextStripper pdfStripper = null;
        PDDocument pdDoc = null;
        COSDocument cosDoc = null;
        File file = new File(fname);
        try {
            PDFParser parser = new PDFParser(new FileInputStream(file));
            parser.parse();
            cosDoc = parser.getDocument();
            pdfStripper = new PDFTextStripper();
            pdDoc = new PDDocument(cosDoc);
            String parsedText = pdfStripper.getText(pdDoc);
            return parsedText;
        } catch (IOException e) {
            e.printStackTrace();
        } 
        return null;
	}
	private HashSet<String> buildStopList() throws Exception{
		RandomAccessFile raf = new RandomAccessFile("stoplist2_en.txt", "r");
		String line;
		String[] str;
		HashSet<String> set = new HashSet<String>();
		while((line=raf.readLine())!=null){
			str=line.trim().split(",");
			for(int i=0;i<str.length;i++){
				set.add(str[i].trim());
			}
		}
		return set;
	}
}
