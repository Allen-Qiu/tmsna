package qjt.wm.freq;

import java.io.IOException;
import java.io.StringReader;

import org.apache.lucene.analysis.Analyzer;
import org.apache.lucene.analysis.TokenStream;
import org.apache.lucene.analysis.tokenattributes.CharTermAttribute;
import org.apache.lucene.analysis.tokenattributes.TypeAttribute;
import org.wltea.analyzer.lucene.IKAnalyzer;

public class ChineseTokenizerTest {
	public static void main(String[] args) {
		String s="lao������ʮ����Ĥһ�������̣��������������ԣ���ӭ��������80.90�Ŷ�VXin:xingfudexiaohan ";
		Analyzer analyzer = new IKAnalyzer(true);
		
	    TokenStream ts = null;
		try {
			ts = analyzer.tokenStream("myfield", new StringReader(s));
		    CharTermAttribute term  = ts.addAttribute(CharTermAttribute.class);
		    
		    // ��дһ��TypeAttirbute��
		    TypeAttribute type = ts.addAttribute(TypeAttribute.class);
			ts.reset(); 
			while (ts.incrementToken()) {
				System.out.println(term.toString() + " | " + type.type());
			}
			ts.end();

		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			if(ts != null){
				try {
					ts.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
	    }
		analyzer.close();
	}

}

