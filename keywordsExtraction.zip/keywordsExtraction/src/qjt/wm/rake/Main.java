package qjt.wm.rake;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.io.StringReader;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Set;
import java.util.StringTokenizer;
import java.util.Map.Entry;

import org.apache.lucene.analysis.Analyzer;
import org.apache.lucene.analysis.TokenStream;
import org.apache.lucene.analysis.tokenattributes.CharTermAttribute;
import org.apache.lucene.analysis.tokenattributes.OffsetAttribute;
import org.apache.lucene.analysis.tokenattributes.TypeAttribute;
import org.wltea.analyzer.lucene.IKAnalyzer;

/**
 * �ⲿ����RAKE�Ľ���
 * -- 2017.03 -- Qiu
 * */
public class Main {
	
	
	public String run(String file, int isEng, int k) throws Exception{
		if(isEng==1){
			return run(file,true,k);
		}else{
			return run(file,false,k);
		}
	}
	
	/**
	 * run��������Ҫ���������ļ���file;�Ƿ���Ӣ���ĵ���true��ʾ�ǣ�false��ʾ�������ĵ���
	 * kָʾ���ǰk��keywords
	 * */
	public String run(String file, boolean isEng, int k) throws Exception{
		String line=readFile(file);
		List<String> list;
		File f=new File(file);
		Document doc=new Document("",f.getName());
		list=split(line);
		doc.setSentenceList(list);
		AbstractAlgorithm ex;
		
		if(isEng){
		    ex = new EngRakeAlgorithm();
	    	ex.loadStopWordsList("stopLists/FoxStopListEn");
		}else{
			ex = new ChRakeAlgorithm();
			ex.loadStopWordsList("stopLists/stopword2.dic");
		}
	    ex.loadPunctStopWord("stopLists/RakePunctDefaultStopList");

	    //	    PlainTextDocumentReaderLBJEn parser = new PlainTextDocumentReaderLBJEn();
//	    parser.readSource("testCorpus/textAstronomy");
	    ex.init(doc,"");
	    ex.runAlgorithm();
	    ex.setTermList(doc.getTermList());
	    return ex.print(k).toString();
	}
	
	
	/**
	 * ���ձ����Ż��ֳ���Ϊ�̾� 
	 * */
	private List<String> split(String line){
		String delim="��������./,!?{}[];";
//		String delim="��������./,!?{}[];:()-_@";
		StringTokenizer st=new StringTokenizer(line,delim);
		List<String> list=new ArrayList<String>();
		
		while(st.hasMoreTokens()){
			list.add(st.nextToken());
		}
		return list;
	}
		/**
	 * ���ļ�ת����һ������
	 * */
	private String readFile(String fname) throws Exception{
		BufferedReader fis=new BufferedReader(new FileReader(fname));
		String line;
		StringBuilder sb = new StringBuilder();
		while(true){
			line=fis.readLine();
			if(line==null) break;
			if(line.isEmpty()) continue;
			line=line.trim();
			sb.append(line);
		}
		fis.close();
		return sb.toString();
	}
	
}
