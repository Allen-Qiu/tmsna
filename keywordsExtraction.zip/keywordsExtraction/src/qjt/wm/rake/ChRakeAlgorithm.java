package qjt.wm.rake;


import java.io.IOException;
import java.io.StringReader;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.StringTokenizer;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.lucene.analysis.Analyzer;
import org.apache.lucene.analysis.TokenStream;
import org.apache.lucene.analysis.tokenattributes.CharTermAttribute;
import org.apache.lucene.analysis.tokenattributes.OffsetAttribute;
import org.apache.lucene.analysis.tokenattributes.TypeAttribute;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.wltea.analyzer.lucene.IKAnalyzer;

/**
 * �������ĵ�ʹ��RAKE�㷨����keywords��ȡ
 * --2017.03--Qiu
 */

public class ChRakeAlgorithm extends AbstractAlgorithm {

    private transient Document doc = null;
    private final transient List<Term> termList; 
    private List<String> stopWordList;
    transient private final Logger logger = LoggerFactory.getLogger(this.getClass());
    private List<Pattern> regexList = null;
    private List<String> punctList;
    private int minNumberOfletters = 2;
    private Analyzer analyzer;
    
    /**
     *
     */
    public ChRakeAlgorithm() {
        super(true, "RAKE");
        termList = super.getTermList();
        stopWordList = new ArrayList<>();
        regexList = new ArrayList<>();
        punctList = new ArrayList<>();
    }

    @Override
    public void init(Document pDoc, String pPropsDir) {
        setDoc(pDoc);
        doc = pDoc;
    }

    /**
     * This methods requires a list of stopwords to build a the candidate list,
     * will search in each different sentence for this stopwords to delimite the
     * candidate generation
     *
     *
     * @param pStopWords - a list of stopWords
     */
    public void loadStopWordsList(List<String> pStopWords) {
        stopWordList = pStopWords;
    }

    /**
     * This method requires a list of stopwords to build a the candidate list,
     * will search in each different sentence for this stopwords to delimite the
     * candidate generation
     *
     *
     * @param pLoc - the location of the file where the stopwords are
     */
    public void loadStopWordsList(String pLoc) {
        List<String> stops = new ArrayList<>();
        try {
            List<String> words = Files.readAllLines(Paths.get(pLoc), StandardCharsets.UTF_8);
            for (String string : words) {
                stops.add(string.trim());
            }
            stopWordList = stops;
        } catch (IOException ex) {
            logger.error("Error loading RAKE stopWordList from: " + pLoc, ex);
        }
    }

    /**
     * As this method uses Regex for candidate generation, custom regex
     * expresions could be added using this method (uses Java Pattern/Matcher
     * mechanism)
     *
     * @param pat
     */
    public void addCustomRegex(Pattern pat) {
        regexList.add(pat);
    }

    /**
     * This method works better with a list of punctuation stop list, for
     * example for english, spanish and in general in latin based languages the
     * list could be (.,/{}[];:)
     *
     * @param pLoc - the location of the file where the stopwords are
     */
    public void loadPunctStopWord(String pLoc) {
        List<String> stops = new ArrayList<>();
        try {
            List<String> words = Files.readAllLines(Paths.get(pLoc), StandardCharsets.UTF_8);
            for (String string : words) {
                stops.add(string.trim());
            }
            punctList = stops;
        } catch (IOException ex) {
            logger.error("Error loading RAKE punctList from: " + pLoc, ex);
        }
    }

    /**
     * (OPTIONAL)This method works better with a list of punctuation stop list,
     * for example for english, spanish and in general in latin based languages
     * the list could be (.,/{}[];:)
     *
     * @param pPunt - the string list to be added
     */
    public void loadPunctStopWord(List<String> pPunt) {
        punctList = pPunt;
    }

    private List<String> generateCandidateKeywords(List<String> pSentenceList) {
        
    	String regx="";
    	for(int i=0;i<stopWordList.size();i++){
    		regx+=stopWordList.get(i)+"|";
    	}
    	for(int i=0;i<punctList.size();i++){
    		regx+="\\"+punctList.get(i)+"|";
    	}
    	regx=regx.substring(0,regx.length()-1);
    	List<String> candidates = new ArrayList<>();
        String str[];
        
        for (String s : pSentenceList) {
        	str=s.split(regx);
        	for(int i=0;i<str.length;i++){
        		if(str[i].trim().isEmpty()) continue;
        		candidates.add(chSplit(str[i]).trim());
        	}
        }
        return candidates;
    }
    public void runAlgorithm() {
        if (stopWordList.isEmpty()) {
            logger.error("The method " + this.getName() + " requires a StopWordList to build the candidate list");
            return;
        } 
        analyzer = new IKAnalyzer(true);
        Map<String, Integer> wordfreq = new HashMap<>();
        Map<String, Integer> worddegree = new HashMap<>();
        Map<String, Float> wordscore = new HashMap<>();

        List<String> candidates = generateCandidateKeywords(doc.getSentenceList());
        for (String phrase : candidates) {
            String[] wordlist = phrase.split("\\s+");
            int wordlistlength = wordlist.length;
            int wordlistdegree = wordlistlength - 1;
            for (String word : wordlist) {
                int freq;
                if (wordfreq.containsKey(word) == false) {
                    wordfreq.put(word, 1);
                } else {
                    freq = wordfreq.get(word) + 1;
                    wordfreq.remove(word);
                    wordfreq.put(word, freq);
                }
                if (worddegree.containsKey(word) == false) {
                	worddegree.put(word, wordlistdegree);
                } else {
                    int deg = worddegree.get(word) + wordlistdegree;
                    worddegree.remove(word);
                    worddegree.put(word, deg);
                }
            }
        }
        for (Map.Entry<String, Integer> entry : worddegree.entrySet()) {
            entry.setValue(entry.getValue() + wordfreq.get(entry.getKey()));
        }
        List<Term> termLi = new ArrayList<>();
        for (Map.Entry<String, Integer> entry : wordfreq.entrySet()) {
            wordscore.put(entry.getKey(), worddegree.get(entry.getKey()) / (wordfreq.get(entry.getKey()) * 1.0f));
        }
        for (String phrase : candidates) {
            String[] words = phrase.split("\\s+");
            float score = 0.0f;
            for (String word : words) {
                score += wordscore.get(word);
            }
//            termLi.add(new Term(phrase,score));
            termLi.add(new Term(phrase, score/words.length));
        }
        java.util.Collections.sort(termLi);
        
        List<Term> orderedList = termLi;
        doc.setTermList(orderedList);
        analyzer.close();
    }

    /**
     *
     * @return the doc
     */
    public Document getDoc() {
        return doc;
    }

    /**
     * @param doc the doc to set
     */
    public void setDoc(Document doc) {
        this.doc = doc;
    }

    /**
     *
     * Returns the current (Default 2)
     *
     * @return the minNumberOfletters required to a word to be included
     */
    public int getMinNumberOfletters() {
        return minNumberOfletters;
    }

    /**
     * Default 2
     *
     * @param minNumberOfletters the minNumberOfletters to set to a word to be
     * included
     */
    public void setMinNumberOfletters(int minNumberOfletters) {
        this.minNumberOfletters = minNumberOfletters;
    }

     /**
 	 * �����ı����ֳɾ���
 	 * */
 	private String chSplit(String line){
 		String delim="��������./,!?{}[];:()-_@";
 		StringTokenizer st = new StringTokenizer(line, delim);
 		String sentence;
 		TokenStream ts = null;
 		String list="";
 		String token;
 		String str;
 		
 		while(st.hasMoreTokens()){
 			sentence=st.nextToken();
 			str="";
 			
 			try {
 				ts = analyzer.tokenStream("myfield", new StringReader(sentence));
 			    CharTermAttribute term  = ts.addAttribute(CharTermAttribute.class);
 			    
 			    // ��дһ��TypeAttirbute��
 				ts.reset(); 
 				while (ts.incrementToken()) {
 					token=term.toString();
 					str+=token+" ";
 				}
 				list+=str+" ";
 				ts.end(); 
 			} catch (IOException e) {
 				e.printStackTrace();
 			} finally {
 				if(ts != null){
 					try {
 						ts.close();
 					} catch (IOException e) {
 						e.printStackTrace();
 					}
 				}
 		    }
 		}
 		return list;
 	}
}
