package qjt.wm.rake;

public class Test {

	public static void main(String[] args) {
		Main m=new Main();
		try {
			String contents=m.run("rdbg2018.txt",false, 20);
//			String contents=m.run("yelp1_test.txt",true,20);
			System.out.println(contents);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

}
