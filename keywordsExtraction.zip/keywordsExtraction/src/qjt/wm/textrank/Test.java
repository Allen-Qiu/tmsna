package qjt.wm.textrank;
/**
 * ʹ��
 * */
public class Test {

	public static void main(String[] args) {
		Main m=new Main();
		m.setMaxCount(60);
		m.setDamping(0.5);
		m.setOcCount(1);	//
		
		String contents=m.runEng("www2016.txt", 5, true, false);
//		String contents=m.runChinese("rdbg2019.txt", 2);
		System.out.println(contents);
		
	}

}
