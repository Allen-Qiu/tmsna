package qjt.wm.textrank;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.io.RandomAccessFile;
import java.io.StringReader;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Set;
import java.util.StringTokenizer;
import java.util.Vector;
import java.util.Map.Entry;

import org.apache.lucene.analysis.Analyzer;
import org.apache.lucene.analysis.TokenStream;
import org.apache.lucene.analysis.tokenattributes.CharTermAttribute;
import org.wltea.analyzer.lucene.IKAnalyzer;

import edu.stanford.nlp.process.Morphology;

/**
 * ��һƪ�ĵ������ݴʵ佨��TermMatrix
 * 
 * -- 2017.03 -- Qiu
 * */
public class TermMatrixBuilder {
	private Dictionary dic;
	private TermMatrix tm;
	
	public TermMatrixBuilder(Dictionary dic){
		this.dic=dic;
		tm=new TermMatrix(dic);
	}
	public TermMatrix getMatrix(){
		return tm;
	}
	public void engRun(List<String> mlist) throws Exception{
		engPut(mlist);
	}
	public void chRun(List<String> mlist) throws Exception{
		chPut(mlist);
	}
	private void engPut(List<String> mlist){
		String delim=" :�� \'��||\"��������-	";
		StringTokenizer st ;;
		String token;
		Vector<String> terms=new Vector<String>();
		
		for(String str:mlist){
			terms.clear();
			st = new StringTokenizer(str, delim);
			while(st.hasMoreTokens()){
				token=st.nextToken();
				if(token.isEmpty())continue;
				terms.add(token);
			}
			insert2Matrix(terms);
		}
	}
	/**
	 * ʹ�����ķִ�
	 * */
	private void chPut(List<String> mlist){
		Analyzer analyzer = new IKAnalyzer(true);
	    TokenStream ts = null;
	    String token;
	    Vector<String> terms=new Vector<String>();
	    
		try {
			for(String str:mlist){
				terms.clear();
				ts = analyzer.tokenStream("myfield", new StringReader(str));
			    CharTermAttribute term  = ts.addAttribute(CharTermAttribute.class);
				ts.reset(); 
				
				while (ts.incrementToken()) {
					token=term.toString();
					if(token.trim().isEmpty()) continue;
					terms.add(token);
				}
				ts.end(); 
				insert2Matrix(terms);
			}
		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			if(ts != null){
				try {
					ts.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
	    }
		analyzer.close();
	}
	/**
	 * �Ӿ��ӽ����ʵĹ������ھ����н�������
	 * */
	private void insert2Matrix(Vector<String> terms){
		String t1,t2;
		Integer idx1, idx2;
		float val;
		
		for(int i=0;i<terms.size()-1;i++){
			t1=terms.get(i);
			idx1=dic.getIdx(t1);
			t2=terms.get(i+1);
			idx2=dic.getIdx(t2);
			if(idx1!=null&&idx2!=null){
				val=tm.get(idx1, idx2);
				tm.set(idx1, idx2, val+1);
			}
		}
	}
}
