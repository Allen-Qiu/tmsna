package qjt.wm.textrank;

import java.util.List;

import qjt.wm.freq.MyList;

/**
 * ��textrank��ȡ�ؼ��ʵģ��ⲿ���ý���
 * -- 2017.03 -- Qiu
 * */
public class Main {
	private double damping=0.5;
	
	
	private int maxCount=100;
	private int ocCount=1;
	
	/**
	 * ����dampingϵ����Ҳ���Բ��������ã�Ĭ��ֵ��0.5
	 * */
	public void setDamping(double damping){
		this.damping=damping;
	}
	/**
	 * �����������Ĺؼ��ʸ�������������ã�Ĭ��ֵ��100.
	 * */
	public void setMaxCount(int k){
		maxCount=k;
	}
	/**
	 * ��ѡ�γɵ�keywords������������������һ���Ĺ��ִ�����Ĭ��ֵ��0
	 * */
	public void setOcCount(int k){
		ocCount=k;
	}
	public String runEng(String fname, int min){
		return runEng(fname,min,true, false);
	}
	
	/**
	 * ����Ӣ���ĵ�
	 * @param fname ���������ĵ����ĵ���
	 * @param min ��ѡ��Ƶ����min�Ĵ���
	 * @param useStopList ʹ��ͣ�ôʱ���
	 * @param useStem �ʸɻ���
	 * */
	public String runEng(String fname, int min, boolean useStopList, boolean useStem){
		DicBuilder builder=new DicBuilder(min);
		Dictionary dic;
		List<String> mlist;
		TermMatrix tm;
		TermMatrixBuilder tBuilder;
		
		try{
			FileProcess.run(fname);
			mlist=FileProcess.get();
			builder.engRun(FileProcess.get(), useStopList, useStem);
			dic=builder.getDic();
			System.out.println("Dictionary size: "+dic.size());
			
			tBuilder=new TermMatrixBuilder(dic);
			tBuilder.engRun(mlist);
			tm=tBuilder.getMatrix();
			
			return runTextRank(tm, dic);
		}catch(Exception e){
			e.printStackTrace();
		}
		return null;
	}
	/**
	 * ���������ĵ�
	 * @param fname ���������ĵ���
	 * @param min ��ѡ��Ƶ����min�Ĵ���
	 * */
	public String runChinese(String fname, int min){
		DicBuilder builder=new DicBuilder(min);
		Dictionary dic;
		List<String> mlist;
		TermMatrix tm;
		TermMatrixBuilder tBuilder;
		
		try{
			FileProcess.run("rdbg2015.txt");
			mlist=FileProcess.get();
			builder.chRun(FileProcess.get());
			dic=builder.getDic();
			System.out.println("Dictionary Size: "+dic.size());
			
			tBuilder=new TermMatrixBuilder(dic);
			tBuilder.chRun(mlist);
			tm=tBuilder.getMatrix();
			return runTextRank(tm, dic);
		}catch(Exception e){
			e.printStackTrace();
		}
		return null;
	}
	
	private String runTextRank(TermMatrix tm, Dictionary dic){
		StringBuffer sb=new StringBuffer();
		
		double[] init=new double[tm.getNum()];
		MyList mlist=new MyList(maxCount);
		
		for(int i=0;i<init.length;i++){
			init[i]=0.5;
		}
		
		TextRank tr=new TextRank(tm, init, damping);
		tr.calScore();
		
		for(int i=0;i<tr.Rj.length;i++){
			mlist.insert(dic.getTerm(i), tr.Rj[i]);
		}
		mlist.print();
		
		/* build keywords */
		System.out.println("------ keywords ------");
		mlist=new MyList(maxCount);
		
		for(int i=0;i<tr.Rj.length;i++){
			mlist.insert(i+"", tr.Rj[i]);
		}
		String idx;
		int count=0;
		int[] iList=new int[mlist.size()];
		while(true){
			idx=mlist.next();
			if(idx==null) break;
			iList[count++]=Integer.parseInt(idx);
		}
		
		for(int i=0;i<iList.length-1;i++){
			for(int j=i+1;j<iList.length;j++){
				if(tm.get(iList[i], iList[j])>ocCount){
//					System.out.println(dic.getTerm(iList[i])+" "+dic.getTerm(iList[j]));
					sb.append(dic.getTerm(iList[i])+" "+dic.getTerm(iList[j])+"\n");
				}
			}
		}
		return sb.toString();
		
//		System.out.println("--------");
//		boolean[] processed=new boolean[iList.length];
//		String str;
//		
//		/* generating keywords */
//		for(int i=0;i<iList.length-1;i++){
//			if(processed[i]) continue;
//			str=dic.getTerm(iList[i]);
//			
//			for(int j=i+1;j<iList.length;j++){
//				if(processed[j]) continue;
//				if(tm.get(iList[i], iList[j])>ocCount){
//					str+=" "+dic.getTerm(iList[j]);
//					processed[j]=true;
//					processed[i]=true;
//				}
//			}
//			if(processed[i]){
//				System.out.println(str);
//			}
//		}
	}
}
