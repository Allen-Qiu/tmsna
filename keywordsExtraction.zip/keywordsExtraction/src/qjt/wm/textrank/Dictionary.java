package qjt.wm.textrank;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map.Entry;
import java.util.Set;

/**
 * �ʵ䣺����һ���ӱ�ŵ��ʵ�ӳ���һ���Ӵʵ���ŵ�ӳ��
 * 
 * -- 2017.03 -- Qiu
 * */
public class Dictionary implements java.io.Serializable{
	private HashMap<String, Integer> tset;	
	private HashMap<Integer, String> iset;
	private int maxIdx;
	
	public Dictionary(){
		tset=new HashMap<String, Integer>();
		iset=new HashMap<Integer, String>();
		maxIdx=0;
	}
	
	public void put(String term){
		if(tset.get(term)!=null) return;
		tset.put(term, maxIdx);
		iset.put(maxIdx, term);
		maxIdx++;
	}
	public Integer getIdx(String term){
		return tset.get(term);
	}
	public String getTerm(int idx){
		return iset.get(idx);
	}
	public void print(){
		java.util.SortedMap<String, Integer> smap=new java.util.TreeMap<String, Integer>();
		java.util.Set<java.util.Map.Entry<String, Integer>>  kset=tset.entrySet();
		Iterator<Entry<String, Integer>> kit=kset.iterator();
		Entry<String, Integer> kentry;
		
		while(kit.hasNext()){
			kentry=kit.next();
			if(kentry.getKey()!=null){
				smap.put(kentry.getKey(), kentry.getValue());
			}else{
				System.out.println(kentry);
			}
		}
		
		Set<Entry<String, Integer>> set = smap.entrySet();
		Iterator<Entry<String, Integer>> it=set.iterator();
		Entry<String, Integer> entry;
		
		while(it.hasNext()){
			entry=it.next();
			System.out.println(entry.getKey()+":"+entry.getValue());
		}
	}
	public int size(){
		return iset.size();
	}
}
