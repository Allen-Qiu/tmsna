package qjt.wm.textrank;

import java.io.IOException;
import java.io.RandomAccessFile;
import java.io.StringReader;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Set;
import java.util.StringTokenizer;
import java.util.Map.Entry;

import org.apache.lucene.analysis.Analyzer;
import org.apache.lucene.analysis.TokenStream;
import org.apache.lucene.analysis.tokenattributes.CharTermAttribute;
import org.wltea.analyzer.lucene.IKAnalyzer;

import edu.stanford.nlp.process.Morphology;

/**
 * ��һƪ�ĵ������ʵ�
 * 
 * -- 2017.03 -- Qiu
 * */
public class DicBuilder {
	private int minCount;	// ѡ�����minCount�Ĵ���
	private Dictionary dic;
	
	public DicBuilder(int min){
		minCount=min;
		dic=new Dictionary();
	}
	public Dictionary getDic(){
		return dic;
	}
	public void engRun(List<String> mlist, boolean useStopList, boolean useStem) throws Exception{
		HashMap<String, Integer> hmap=new HashMap<String, Integer>();
		
		engPut(mlist,hmap,useStopList, useStem);
		buildDic(hmap);
	}
	public void chRun(List<String> mlist) throws Exception{
		HashMap<String, Integer> hmap=new HashMap<String, Integer>();
		chPut(mlist,hmap);
		buildDic(hmap);
	}
	private void buildDic(HashMap<String, Integer> hmap){
		Set<Entry<String, Integer>> set = hmap.entrySet();
		Iterator<Entry<String, Integer>>  it = set.iterator();
		Entry<String, Integer> entry;
		while(it.hasNext()){
			entry = it.next();
			if(entry.getValue()>minCount){
				dic.put(entry.getKey());
			}
		}
	}
	
	private void engPut(List<String> mlist, 
						HashMap<String, Integer> hmap,
						boolean useStopList, 
						boolean useStem) throws Exception{
		HashSet<String> stoplist = null;
		Morphology m=null;
		
		if(useStopList){
			stoplist = buildStopList();
		}
		if(useStem){
			m=new Morphology();
		}
		String delim=" ,.?:()";
		StringTokenizer st ;;
		String token;
		Integer count;
		
		for(String str:mlist){
			st = new StringTokenizer(str, delim);
			while(st.hasMoreTokens()){
				token=st.nextToken();
				if(token.isEmpty())continue;
				if(m!=null){
					token = m.stem(token);
					if(token.isEmpty()) continue;
				}
				if(stoplist!=null && stoplist.contains(token)) continue;
				count = hmap.get(token);
				if(count==null){
					hmap.put(token, 1);
				}else{
					hmap.put(token, count+1);
				}
			}
		}
		
	}
	/**
	 * ʹ�����ķִ�
	 * */
	private void chPut(List<String> mlist, HashMap<String, Integer> hmap){
		Analyzer analyzer = new IKAnalyzer(true);
		
	    TokenStream ts = null;
	    String token;
	    Integer count;
	    
		try {
			for(String str:mlist){
				ts = analyzer.tokenStream("myfield", new StringReader(str));
			    CharTermAttribute term  = ts.addAttribute(CharTermAttribute.class);
				ts.reset(); 
				
				while (ts.incrementToken()) {
					token=term.toString();
					count = hmap.get(token);
					if(count==null){
						hmap.put(token, 1);
					}else{
						hmap.put(token, count+1);
					}
				}
				ts.end(); 
			}
		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			if(ts != null){
				try {
					ts.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
	    }
		analyzer.close();
	}
	private HashSet<String> buildStopList() throws Exception{
		RandomAccessFile raf = new RandomAccessFile("stopLists/stoplist2_en.txt", "r");
		String line;
		String[] str;
		HashSet<String> set = new HashSet<String>();
		while((line=raf.readLine())!=null){
			str=line.trim().split(",");
			for(int i=0;i<str.length;i++){
				set.add(str[i].trim());
			}
		}
		raf.close();
		return set;
	}
}
