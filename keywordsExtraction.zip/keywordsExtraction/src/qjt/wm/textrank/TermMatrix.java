package qjt.wm.textrank;

import java.util.Vector;


/**
 * �������
 * 
 * -- 2017.03 -- Qiu
 * */
public class TermMatrix {
	private float[][] matrix;
	private Dictionary dic;
	private int size;
	
	public TermMatrix(float[][] m){
		matrix=m;
		size=m.length;
	}
	public TermMatrix(Dictionary dic){
		this.dic=dic;
		size=dic.size();
		matrix=new float[size][size];
	}
	public void set(int idx1, int idx2, float val){
		matrix[idx1][idx2]=val;
		matrix[idx2][idx1]=val;
	}
	public float get(int idx1, int idx2){
		return matrix[idx1][idx2];
	}
	public void print(){
		for(int i=0;i<size;i++){
			for(int j=0;j<=i;j++){
				if(matrix[i][j]>0){
					System.out.println(dic.getTerm(i)+" "+dic.getTerm(j)+" "+matrix[i][j]);
				}
			}
		}
	}
	/**
	 * ��ȡ�����еĽڵ���
	 * */
	public int getNum(){
		return size;
	}
	/**
	 * ����һ���ڵ�idx�������ýڵ������������ڵ�ı��
	 * */
	public Vector<Integer> getConnNodes(int idx){
		Vector<Integer> vec=new Vector<Integer>();
		for(int i=0;i<size;i++){
			if(matrix[idx][i]>0){
				vec.add(i);
			}
		}
		return vec;
	}
	/**
	 * �����ڵ�idx�����ıߵ�Ȩ�غ�
	 * */
	public float getWeightsSum(int idx){
		float sum=0;
		for(int i=0;i<size;i++){
			sum+=matrix[idx][i];
		}
		return sum;
	}
	public float[][] getMatrix(){
		return matrix;
	}
}




