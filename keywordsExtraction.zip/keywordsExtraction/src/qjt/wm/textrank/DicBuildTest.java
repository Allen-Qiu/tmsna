package qjt.wm.textrank;

import java.util.List;

public class DicBuildTest {

	public static void main(String[] args) {
		DicBuilder builder=new DicBuilder(50);
		boolean useStopList=true;
		boolean useStem=true;
		Dictionary dic;
		
		try{
//			FileProcess.run("www2016.txt");
			FileProcess.run("rdbg2015.txt");
//			builder.engRun(FileProcess.get(), useStopList, useStem);
			builder.chRun(FileProcess.get());
			dic=builder.getDic();
			dic.print();
			System.out.println(dic.size());
		}catch(Exception e){
			e.printStackTrace();
		}
		
	}

}
