package qjt.wm.textrank;

public class TextRankTest {

	public static void main(String[] args) {
		TermMatrix tm;
		double[] init;
		double dampling=0.5;
		float[][] m={
				{0,0,0,1,0,0,0,0,0,0,0},                  //a
				{0,0,1,1,1,1,1,1,1,0,0},                  //b
				{0,1,0,0,0,0,0,0,0,0,0},                  //c
				{1,1,0,0,1,0,0,0,0,0,0},                  //d
				{0,1,0,1,0,1,1,1,1,1,1},                  //e
				{0,1,0,0,1,0,0,0,0,0,0},                  //f
				{0,1,0,0,1,0,0,0,0,0,0},                  //g
				{0,1,0,0,1,0,0,0,0,0,0},                  //h
				{0,1,0,0,1,0,0,0,0,0,0},                  //i
				{0,0,0,0,1,0,0,0,0,0,0},                  //j
				{0,0,0,0,1,0,0,0,0,0,0}                   //k
		};
		
		tm=new TermMatrix(m);
		init=new double[m.length];
		for(int i=0;i<init.length;i++){
			init[i]=0.5;
		}
		
		TextRank tr=new TextRank(tm, init, dampling);
		tr.calScore();
		char ch='A';
		
		for(int i=0;i<init.length;i++){
			System.out.println(((char)(ch+i))+":"+tr.Rj[i]);
		}
	}

}
