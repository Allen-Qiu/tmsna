package qjt.wm.textrank;

import java.util.List;

public class TermMatrixBuildTest {

	public static void main(String[] args) {
		DicBuilder builder=new DicBuilder(5);
		boolean useStopList=true;
		boolean useStem=true;
		Dictionary dic;
		List<String> mlist;
		TermMatrix tm;
		boolean isEng=false;
		
		try{
			if(isEng){
				FileProcess.run("www2016.txt");
				mlist=FileProcess.get();
				builder.engRun(mlist, useStopList, useStem);
			}else{
				FileProcess.run("rdbg2015.txt");
				mlist=FileProcess.get();
				builder.chRun(mlist);
			}
			dic=builder.getDic();
			System.out.println(dic.size());
			TermMatrixBuilder tBuilder=new TermMatrixBuilder(dic);
			
			if(isEng){
				tBuilder.engRun(mlist);
			}else{
				tBuilder.chRun(mlist);
			}
			tm=tBuilder.getMatrix();
			tm.print();
		}catch(Exception e){
			e.printStackTrace();
		}
	}

}
