package qjt.wm.textrank;

import java.util.Vector;

/**
 * �����Ȩͼ�е�PageRank
 * */
public class TextRank{
	double d=0.5;           //dampling factor
	int n;           		//number of pages
	double[] E,Ri,Rj;
	
	TermMatrix tm;
	/**
	 * @param  ps  �þ����ʾ��ͼ
	 * @param init ��ʼ����
	 * @param dampingϵ��
	 * */
	public TextRank(TermMatrix tm,double[] init, double dampling){
		E=init;
		d=dampling;
		this.tm=tm;
		Ri=init.clone();
		Rj=init.clone();
		n=init.length;
		if(Ri.length!=tm.getNum()){
			System.out.println("Array 'init' length is error! ");
			System.exit(1);
		}
	}
	/**
	 * �����index�ڵ��score
	 * */
	private void nodeScore(int index){
		Vector<Integer> inDegree=tm.getConnNodes(index);
		double num=0,temp,sum;
		
		for(int i=0,len=inDegree.size();i<len;i++){
			sum=tm.getWeightsSum(inDegree.get(i));
			temp=tm.get(index, inDegree.get(i))*Ri[inDegree.get(i)]/sum;
			num+=temp;
		}
		Rj[index]=(1-d)/n +d*num;
	}
	public double[] getScores(){
		return Rj;
	}
	private void onePassCalScore(){
		for(int i=0;i<n;i++){
			nodeScore(i);
		}
	}
	public void calScore(){
		double e,gama;
		double[] t=new double[n];
		int k=0;
		do{
			onePassCalScore();
			e=calNorm(Ri)-calNorm(Rj);
			for(int i=0;i<Rj.length;i++){
				Rj[i]+=e*E[i];
				t[i]=Math.abs(Rj[i]-Ri[i]);
			}
			gama=calNorm(t);
			Ri=Rj.clone();
//			if(gama>0.9)break;
//			System.out.println(gama);
			k++;
			if (k>100||gama<0.001)break;
		}while(true);
		normalize(Rj);
	}
	/**
	 * ����������L1����
	 * */
	private double calNorm(double[] r){
		double num=0;
		for(int i=0;i<r.length;i++){
			num+=r[i];
		}
		return Math.sqrt(num);
	}
	/**
	 * ������淶��,���ü���ֵ�淶��
	 * */
	private void normalize(double[] s){
		double max=0;
		for(int i=0;i<s.length;i++){
			if(s[i]>max) max=s[i];
		}
		for(int i=0;i<s.length;i++){
			s[i]/=max;
		}
	}
}
