package qjt.wm.textrank;

import java.io.BufferedReader;
import java.io.FileReader;
import java.util.ArrayList;
import java.util.List;
import java.util.StringTokenizer;

/**
 * ���ļ��ָ�ɶ̾���
 * */
public class FileProcess {
	private static List<String> mlist;
	
	public static List<String> get(){
		return mlist;
	}
	public static void run(String fname) throws Exception{
		String line=readFile(fname);
		mlist=split(line);
		
	}
	/**
	 * ���ļ�ת����һ������
	 * */
	private static String readFile(String fname) throws Exception{
		BufferedReader fis=new BufferedReader(new FileReader(fname));
		String line;
		StringBuilder sb = new StringBuilder();
		while(true){
			line=fis.readLine();
			if(line==null) break;
			if(line.isEmpty()) continue;
			line=line.trim();
			sb.append(line);
		}
		fis.close();
		return sb.toString();
	}
	/**
	 * */
	private static List<String> split(String line){
		String delim="��������./,!?{}[];:()-_@";
		StringTokenizer st=new StringTokenizer(line,delim);
		List<String> list=new ArrayList<String>();
		
		while(st.hasMoreTokens()){
			list.add(st.nextToken());
		}
		return list;
	}
}
