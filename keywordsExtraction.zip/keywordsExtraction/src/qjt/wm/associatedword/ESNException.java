package qjt.wm.associatedword;
/**
 * self exception for esn
 * 2014.06
 * */
public class ESNException extends Exception{
	private String info;
	public ESNException(String info){
		this.info=info;
	}
	 public String toString(){
		 return "ESNException:["+info+"]";
	 }
}
