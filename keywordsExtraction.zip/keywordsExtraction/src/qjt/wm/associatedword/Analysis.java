package qjt.wm.associatedword;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;

import qjt.wm.textrank.Dictionary;

public class Analysis {
	public static void main(String[] args){
		try {
			Dictionary dic = serialize();
			dic.print();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	private static Dictionary serialize() throws Exception{
		Dictionary dic = null;
		
		try{
			ObjectInputStream ModelIn=
				new ObjectInputStream(
					new FileInputStream("dic.out"));
			dic = (Dictionary)ModelIn.readObject();
			ModelIn.close();
		}catch(IOException e){
			e.printStackTrace();
		}
		return dic;
	}
}
