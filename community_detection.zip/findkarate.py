'''
Created on 2015年11月13日

@author: qjt
'''
import networkx as nx
import myCommFind as my

# G = nx.karate_club_graph()
# cliques = nx.find_cliques(G)
# k=4
# nodes = list(nx.k_clique_communities(G, k, cliques))

# for i in range(len(nodes)):
#     print([node for node in nodes[i]])


f=my.MyCommFind()
g = nx.karate_club_graph()
nlist=g.nodes()   
p=0.5
step=6
numofcomm=3

comm = f.find(g,p,step,numofcomm)
for a in comm:
    clist = [i+1 for i in comm[a]]
    clist.sort()
    print(str(a)+":"+str(clist))
