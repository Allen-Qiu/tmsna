'''
employing random walk on graph and non-negative matrix factorization
to detect communities.

For Python 3.4

Created on 11.12.2015
@author: Jiangtao Qiu
'''
import numpy
import networkx as nx

class MyCommFind:
    sp = 0.5
    step = 6
    
    def find(self, g, sp, step, numofcomm):
        ''' sp: self-transfer probability
            step: the number of steps
            numofcomm: the number of communities
        '''
        matrix = nx.to_numpy_matrix(g)
        self.sp=sp
        self.step=step
        
        size = len(g.nodes())

        # -- generate one step transition matrix
        mone = numpy.sum(matrix, 1)
        ones = numpy.ones((1,len(mone)), dtype=None )
        mone = (1-self.sp)*matrix/(mone*ones)
        
        seye = numpy.eye(size, size) * self.sp
        mone=seye+mone
        
        # -- transition matrix
        sm = mone
        for i in range(1,step):
            sm = numpy.dot(sm,mone)

        (W,H)=self.mynmf(sm,numofcomm)
        r=H.T
        #-- obtain dividing result
        (row, col)=r.shape
        r = numpy.argmax(r, axis=1)
        comm={}
        for i in range(col):
            comm[i]=[] 
            
        for i in range(0, row):
            comm[r[i,0]].append(i) 
        return comm
    
    def mynmf(self, V,k):
        ''' k is rank. return (W,H)
        '''
        (row,col)=V.shape
        EPS=0.000001
        W=numpy.random.rand(row,k)
        H=numpy.random.rand(k,col)
        d1=2
        delta=1
        Hk=H
        Wk=W
        
        while (abs(delta-d1)>EPS):
            d1=delta
            Hkt=Hk.T
            V1=numpy.dot(V,Hkt)
            W1=numpy.dot(numpy.dot(Wk,Hk),Hkt)+EPS
            vv=V1/W1
            Wk=Wk/(1/vv)
            Wkt=Wk.T
            V2=numpy.dot(Wkt,V);
            W2=numpy.dot(numpy.dot(Wkt,Wk),Hk)+EPS
            vv=V2/W2
            Hk=Hk/(1/vv)
            delta=numpy.linalg.norm(V-numpy.dot(Wk,Hk),ord='fro')
            
        W=Wk;H=Hk
        return(W,H)
    
