'''
Created on 2015年11月12日

@author: qjt
'''
import myCommFind as my
import networkx as nx

f=my.MyCommFind()
#g = nx.karate_club_graph()
#g = nx.read_adjlist('fig1.adj')
#g = nx.read_adjlist('cg1.adj')
g = nx.read_edgelist('cg2.edg')
# g = nx.read_gml('lesmis.gml')

nlist=list(g.nodes())   
p=0.5
step=4
numofcomm=3

comm = f.find(g,p,step,numofcomm)
for a in comm:
    clist = [nlist[i] for i in comm[a]]
#     clist.sort()
    print(str(a)+":"+str(clist))
    
