'''
Created on 11.12.2015
convert matrix to edgelist
@author: qjt
'''
fin = "cg2.matrix"
fout = "cg2.edg"
k=0
out = open (fout,"w+" )

with open(fin) as f:
    for x in f.readlines ():
        line = x.strip ()
        if line=="": continue
        mlist = line.split (" ")
        for m in range(0,len(mlist)):
            if mlist[m]=='1':
                out.write('v'+str(k+1)+" v"+str(m+1)+"\n")
        k=k+1
        
out.close()
