'''
Created on 2015年11月16日

@author: qjt
'''
import networkx as nx

G=nx.read_adjlist('fig1.adj')
cliques = nx.find_cliques(G)
k=3
nodes = list(nx.k_clique_communities(G, k, cliques))

for i in range(len(nodes)):
    print([node for node in nodes[i]])
